function fcnSniffV2_Close(~,~)

    global sessDaq
    global vidAVT
    global S_TrlInfo
    global S_GUI
    
    % stop timer
    stop (S_TrlInfo.tmrSmpl)
    delete (S_TrlInfo.tmrSmpl)
    clear S_TrlInfo.tmrSmpl
    
    % shut down data acquisition session
    S_TrlInfo.arrVlvCtrl(:) = 0;
    sessDaq.outputSingleScan(S_TrlInfo.arrVlvCtrl);
    stop (sessDaq)
    delete (sessDaq)
    clear sessDaq
    
    % shut down video input object
    stop(vidAVT)
    delete(vidAVT)
    clear vidAVT
    
    % close control panel and video figures
    close (S_GUI.CtrlPnl)
    close (S_GUI.hFigVid)
    disp('.')
    disp('.')
    
end

