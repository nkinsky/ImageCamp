function fcnSniffV2_Punish(vPortID)
    
    % use digital output to valves to deliver air puff 
    % if animal makes nose poke in non-target port

    global S_TrlInfo
    global sessDaq
    
    % if animal is not still drinking after initial nose poke
    if ~S_TrlInfo.FlgDrnk
        % then deliver punishment signal (air puff) from selected port
        if S_TrlInfo.PnshOn
            if ~(strcmp(S_TrlInfo.tmrPnshCtrl.Running,'on'))
                S_TrlInfo.arrVlvCtrl(8+vPortID) = 1;
                sessDaq.outputSingleScan(S_TrlInfo.arrVlvCtrl);
                start(S_TrlInfo.tmrPnshCtrl)
            end 
        end
    end
    
    % output trial info to workspace history
    if ~(S_TrlInfo.FlgDspOutp)
        S_TrlInfo.FlgDspOutp = 1;
        disp(['trial: ',num2str(S_TrlInfo.CurrTrl), ...
              '   target: ',num2str(S_TrlInfo.PortTrgt), ...
              '   selected: ',num2str(vPortID), ...
              '   incorrect'])
    end
    
end
