function fcnSniffV2_Smpl(~,~)

    % digital sampling function called by timer 
    % checks state of each beam break
    % sampling interval set byt S_TrlInfo.SmplIntvl

    global sessDaq
    global S_TrlInfo
    
    %disp(S_TrlInfo.tmrRwrdCtrl.Running)
    
    % read digital inputs from board
    arrBmBrk = sessDaq.inputSingleScan;
    
    if sum(arrBmBrk)>0                  % if nonzero value in anyh channel indicates nose poke
        if S_TrlInfo.FlgBmBrk==0        % and animal is not still holding position from previous beam break
            vPortID = find(arrBmBrk);   % then determine which port was active
            fcnSniffV2_BmBrk(vPortID)   % and call routine to determine reward or punish
        end
        
    elseif sum(arrBmBrk)==0
        S_TrlInfo.FlgDspOutp = 0;
        if S_TrlInfo.FlgBmBrk==1    
            S_TrlInfo.FlgBmBrk = 0;     % reset beambreak flag to zero when animal LEAVES port
        end
    end
     
end

