function fcnSniffV2_VidSetup
    
    global vidAVT
    global S_Vid
    global S_TrlInfo
    
    % make filename
    vidAVT = videoinput('avtmatlabadaptor64_r2009b',1);
    set(vidAVT,'FramesPerTrigger',S_Vid.NFrms)
    set(vidAVT,'StopFcn', @fcnSniffV2_VidGetDat)  
    disp('Video acquisition setup complete.')
    
end

    
    
 

