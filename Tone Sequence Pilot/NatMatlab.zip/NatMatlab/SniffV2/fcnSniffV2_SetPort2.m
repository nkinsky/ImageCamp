 %-------------------------------------------------------------------------
 function fcnSniffV2_SetPort2(~,~)
    global S_TrlInfo
    global S_GUI
    set(S_GUI.Btn(S_TrlInfo.PortTrgt),'BackgroundColor',S_GUI.Gray)
    S_TrlInfo.PortTrgt = 2;
    set(S_GUI.Btn(S_TrlInfo.PortTrgt),'BackgroundColor',S_GUI.Green)
 end
