
function fcnSniffV2_RwrdPnshOff(~,~)

    global S_TrlInfo
    global sessDaq

    S_TrlInfo.arrVlvCtrl(:) = 0;
    sessDaq.outputSingleScan(S_TrlInfo.arrVlvCtrl);

end