 %-------------------------------------------------------------------------
 function fcnSniffV2_SetPort3(~,~)
    global S_TrlInfo
    global S_GUI
    set(S_GUI.Btn(S_TrlInfo.PortTrgt),'BackgroundColor',S_GUI.Gray)
    S_TrlInfo.PortTrgt = 3;
    set(S_GUI.Btn(S_TrlInfo.PortTrgt),'BackgroundColor',S_GUI.Green)
 end
 