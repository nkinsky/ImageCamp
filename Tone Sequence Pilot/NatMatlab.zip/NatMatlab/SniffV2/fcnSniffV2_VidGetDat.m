function fcnSniffV2_VidGetDat(~,~)
    
    % callback executed at the completion of video acquisition
    % pulls in image data, plots on figure
    
    global vidAVT
    global S_Vid
    global S_GUI
    
    %disp ('getting video data')  
    % check how many frames available
    vNFrms = vidAVT.FramesAvailable;   
    % if video data available
    if vNFrms>1
        % then get from buffer
        [S_Vid.ImgSeq, S_Vid.Ts] = getdata(vidAVT,vNFrms);
        % update video window; put first frame in image window
        S_Vid.NFrms = size(S_Vid.ImgSeq,4);
        vStpMin = 1/S_Vid.NFrms;
        vStpMaj = 0.025;
        set(S_GUI.hSldFrmNum,'SliderStep',[vStpMin vStpMaj], ...
                             'Min',vStpMin,...
                             'Value',vStpMin);
        S_GUI.NFrmsStr = num2str(S_Vid.NFrms);                
        set(S_GUI.hTxtFrmMax,'String',S_GUI.NFrmsStr);
        fcnSniffV2_FrmNumUpd
        % turn save button back to gray to indicate finished
        set (S_GUI.BtnVidAcq,'BackgroundColor',S_GUI.Gray);
    end
    
end
