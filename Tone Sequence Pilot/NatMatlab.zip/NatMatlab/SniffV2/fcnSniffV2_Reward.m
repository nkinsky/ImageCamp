function fcnSniffV2_Reward(vPortID)
    
    % use digital output to valves to deliver water drop
    % if animal makes nose poke in correct target port
    
    global S_TrlInfo
    global sessDaq
        
    % deliver water drop at appropriate location
    if S_TrlInfo.RwrdOn && ~S_TrlInfo.FlgBmBrk && ~S_TrlInfo.FlgDrnk 
        %if ~(strcmp(S_TrlInfo.tmrRwrdCtrl.Running,'on'))
            S_TrlInfo.arrVlvCtrl(vPortID) = 1;
            sessDaq.outputSingleScan(S_TrlInfo.arrVlvCtrl);
            start(S_TrlInfo.tmrRwrdCtrl)
            start(S_TrlInfo.tmrDrnkReset)
        %end
    end
    
    % output trial info to workspace history
    if ~(S_TrlInfo.FlgDspOutp)
        S_TrlInfo.FlgDspOutp = 1;
        disp(['trial: ',num2str(S_TrlInfo.CurrTrl), ...
              '   target: ',num2str(S_TrlInfo.PortTrgt), ...
              '   selected: ',num2str(vPortID), ...
              '   correct'])
    end
    
end
