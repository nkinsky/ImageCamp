%-------------------------------------------------------------------------
 function fcnSniffV2_SetPort7(~,~)
    global S_TrlInfo
    global S_GUI
    set(S_GUI.Btn(S_TrlInfo.PortTrgt),'BackgroundColor',S_GUI.Gray)
    S_TrlInfo.PortTrgt = 7;
    set(S_GUI.Btn(S_TrlInfo.PortTrgt),'BackgroundColor',S_GUI.Green)
 end
 