function fcnSniffV2_BmBrk(vPortID)

    % this routine called by timer callback code
    % to decide reward/punish this trial depending on 
    % selected target port, and whether this is an
    % outbound or return home trial.

    global S_TrlInfo
    global S_Vid
    
    % on trials where the target is outer reward ports:
    if S_TrlInfo.FlgOdrTrl == 1  
        if vPortID==S_TrlInfo.PortTrgt
            if S_TrlInfo.FlgDrnk==0; 
                % reward if correct target
                fcnSniffV2_Reward(vPortID)
                S_TrlInfo.FlgDrnk = 1;
                S_TrlInfo.FlgBmBrk = 1;
                start(S_Vid.tmrVidStop)
            end
        else
            % punish if wrong choice
            fcnSniffV2_Punish(vPortID);
        end
    end
    
    % similar on  trials where the target is home base:
    if S_TrlInfo.FlgOdrTrl == 0                         
        if vPortID == S_TrlInfo.PortHome   
            fcnSniffV2_Reward(vPortID)
            S_TrlInfo.FlgDrnk = 1;
            S_TrlInfo.FlgBmBrk = 1;
            S_TrlInfo.CurrTrl = S_TrlInfo.CurrTrl+1;
            disp('.')
            if S_TrlInfo.RndmOn
                fcnSniffV2_RndNewPort;
            end
            if S_Vid.FlgAcq==1
                start(S_TrlInfo.tmrVidGetDat);
                if S_Vid.SavOn
                    start(S_TrlInfo.tmrVidSave)
                end
                S_Vid.FlgAcq=0;
            end
        else 
            fcnSniffV2_Punish(vPortID)
        end
    end
    
   
      
end

