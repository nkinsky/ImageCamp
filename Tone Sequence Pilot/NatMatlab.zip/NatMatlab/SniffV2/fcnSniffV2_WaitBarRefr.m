
function fcnSniffV2_WaitBarRefr(~,~)
    
    global vidAVT
    global S_Vid
    global S_GUI

    if ~isrunning(vidAVT)
        stop(S_GUI.tmrWaitBarRefr)
    end
    waitbar(vidAVT.FramesAvailable/S_Vid.NFrms,S_GUI.hVidAcqProgBar)

end
