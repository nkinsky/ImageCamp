%-------------------------------------------------------------------------
 function fcnSniffV2_RndNewPort(~,~)
    
    global S_TrlInfo

    vNumPrts = size(S_TrlInfo.ArrPortIDs,2);
    vRnd = randi(vNumPrts,1);
    vPortID = S_TrlInfo.ArrPortIDs(vRnd);
    %disp('new port:')
    switch vPortID
        case 1
            fcnSniffV2_SetPort1
        case 2
            fcnSniffV2_SetPort2
        case 3
            fcnSniffV2_SetPort3
        case 4
            fcnSniffV2_SetPort4
        case 5
            fcnSniffV2_SetPort5
        case 6
            fcnSniffV2_SetPort6
        case 7
            fcnSniffV2_SetPort7
        case 8
            fcnSniffV2_SetPort8
    end
    
 end