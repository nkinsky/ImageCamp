%------------------------------------------------------------------------
function fcnSniffV2_FrmNumUpd(~,~)

    global S_Vid
    global S_GUI
    
    % read slider value and round off for integer value
    S_GUI.CurrFrmVal = round(get(S_GUI.hSldFrmNum,'Value')*S_Vid.NFrms);
    % set slider and label display to integer value
    set(S_GUI.hSldFrmNum,'Value',S_GUI.CurrFrmVal/S_Vid.NFrms);
    S_GUI.CurrFrmStr = num2str(S_GUI.CurrFrmVal);
    while size(S_GUI.CurrFrmStr,2)<4
        S_GUI.CurrFrmStr = strcat('0',S_GUI.CurrFrmStr);
    end
    set(S_GUI.hTxtFrmIndx,'String',S_GUI.CurrFrmStr);
    % update display of image
    set(S_GUI.hImgVid,'Cdata', S_Vid.ImgSeq(:,:,S_GUI.CurrFrmVal));
   
    
end
