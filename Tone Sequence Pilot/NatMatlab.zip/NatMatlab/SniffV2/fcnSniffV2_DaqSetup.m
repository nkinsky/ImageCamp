function fcnSniffV2_DaqSetup
    
    global sessDaq

    %Create session and add channels
    sessDaq = daq.createSession('ni');
    sessDaq.addDigitalChannel('Dev3','port0/line0:7','InputOnly');
    sessDaq.addDigitalChannel('Dev3','port1/line0:7','OutputOnly');
    sessDaq.addDigitalChannel('Dev3','port2/line0:7','OutputOnly');
    disp('Data acquisition setup complete.')
    
end


