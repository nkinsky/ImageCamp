function fcnSniffV2_DrnkReset(~,~)
    
    % called by timer object, started when animal initiates nose poke
    % adds delay before resetting the next target; gives mouse
    % time to get reward before port outcome switches to punishment

    global S_TrlInfo
    
    S_TrlInfo.FlgDrnk = 0;
    
    if S_TrlInfo.FlgOdrTrl == 0
        S_TrlInfo.FlgOdrTrl = 1;
    elseif S_TrlInfo.FlgOdrTrl == 1
        S_TrlInfo.FlgOdrTrl = 0;
    end
     
end
