function fcnSniffV2_VidAcqBeg(~,~)

    % starts video acquisition for the trial
    % AVT guppy pro camera must be configured before running MATLAB
    % (1) plug in firewire camera connection
    % (2) open AVT_SmartView
    % (3) in Format tab, select 120fps from Framerate 
    % (4) in Ctrl 1 tab, set Shutter to 495 
    %        (this is max exposure that allows 100Hz imaging)
    %     and gain to ~300+
    % (5) test with play button; frame rate will show on the image window
    % (6) shut down AVT_SmartView; else driver not available to Matlab
    
    global vidAVT
    global S_Vid
    global S_GUI
    
    %disp('vidacq starting')
        
    % if not already active, start vid acq object  
    if ~(isrunning(vidAVT))
        valVidDur = get(S_GUI.PopVidDur,'Value');
        strVidList = get(S_GUI.PopVidDur,'String');
        strVidDur = strVidList{valVidDur};
        S_Vid.AcqSec = str2num(strVidDur);
        S_Vid.AcqRat = 100; 
        S_Vid.NFrms = S_Vid.AcqSec*S_Vid.AcqRat;
        set(vidAVT,'FramesPerTrigger',S_Vid.NFrms)
        set (S_GUI.BtnVidAcq,'BackgroundColor',S_GUI.Red);
        start(vidAVT)
        S_Vid.FlgAcq = 1;
    else
        disp('video acquisition already running!')
    end
    
    % displayh vid acq progress onscreen until done
    S_GUI.hVidAcqProgBar = waitbar(0,['Video acquisition progress - ',...
                                num2str(S_Vid.AcqSec),...
                                ' sec total']);
    set(S_GUI.tmrWaitBarRefr, 'TasksToExecute',(S_Vid.AcqSec/0.05), ...
                        'StopFcn',@(x,y)close(S_GUI.hVidAcqProgBar));
    start(S_GUI.tmrWaitBarRefr);
    
end

