function fcnSniffV2_VidSave(~,~)
    
    global S_GUI
    global S_Vid
    global S_TrlInfo
    
    % set save button to red
    set (S_GUI.BtnVidSav,'BackgroundColor',S_GUI.Red);
    pause(0.005);
    
    % contruct filename
    strMousID = get(S_GUI.MouseID,'String');
    strSessNum = num2str(S_TrlInfo.CurrSess);
    while size(strSessNum)<2
        strSessNum = strcat('0',strSessNum);
    end
    strTrlNum = num2str(S_TrlInfo.CurrTrl);
    while size(strTrlNum)<3
        strTrlNum = strcat('0',strTrlNum);
    end 
    S_TrlInfo.FilNam = strcat('vid_',strMousID,...
                              '_sn',strSessNum,...
                              'tr',strTrlNum,...
                              '.mat');
    
    % save video data as array in matlab workspace (uncompressed)
    save(S_TrlInfo.FilNam,'S_Vid')
    %pause (1)
    % switch color back on button to show save complete
    set (S_GUI.BtnVidSav,'BackgroundColor',S_GUI.Gray);
    
       % set up writer data
%     writerObj = VideoWriter(S_TrlInfo.FilNam,'Uncompressed AVI');
%     set(writerObj,'FrameRate',100);
%     open(writerObj)
%     writeVideo(writerObj,S_Vid.ImgSeq)
%     close(writerObj)
    
    
end

    
    
 

