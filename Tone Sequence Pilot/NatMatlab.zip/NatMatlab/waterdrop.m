    %Create session and add channels
    sessDAQ = daq.createSession('ni');
    sessDAQ.addAnalogOutputChannel('Dev1',0,'Voltage');
    sessDAQ.addDigitalChannel('Dev1','port0/line0:2','InputOnly');
    pause on

    %t = timer()
    %while(1) 
        x = sessDAQ.inputSingleScan;
        %if x(1)>0
            sessDAQ.outputSingleScan(5);
            pause(0.05); 
            sessDAQ.outputSingleScan(0);
            %break
        %end
        pause (0.05);
    %end

    sessDAQ.stop


