%================================================================= 
function fcnIntrinsicAcq_30(~,~)
    
    % variables and objects for serial and digital IO
    global S_PnlCtrls
    global S_OdrPrms
    global S_DspPrms
    global S_ImgPrms
    global S_ImgDat
    global S_FilePrms
    global sessNI
    global hCbxDspFlt
    
    % set initial values for odor stim
    S_OdrPrms.arrVlvCtrl = zeros(1,8);
    S_OdrPrms.arrVlvCtrl = ([0 0 0 0 0 0 0 0]);
    
    % read imaging info from popup in GUI panel
    valImgSiz = get(S_PnlCtrls.hPopImgSiz,'Value');
    if valImgSiz==1
        S_ImgPrms.ImgSizX = 512;
        S_ImgPrms.ImgSizY = 512;
    elseif valImgSiz==2
        S_ImgPrms.ImgSizX = 1024;
        S_ImgPrms.ImgSizY = 1024;
    end
    % read frame rate info from popup in GUI panel
    valFrmRtHz = get(S_PnlCtrls.hPopFrmRtHz,'Value');
    if valFrmRtHz==1
        S_ImgPrms.FrmRtHz = 30;
    elseif valFrmRtHz==2
        S_ImgPrms.FrmRtHz = 60;
    end
    % read # frames to average for each acq block from popup in GUI panel
    valNFrmsPerBlck = get(S_PnlCtrls.hPopImgSiz,'Value');
    switch valNFrmsPerBlck
        case 1
            S_ImgPrms.NFrmsPerBlck = 5;
        case 2
            S_ImgPrms.NFrmsPerBlck = 10;
        case 3
            S_ImgPrms.NFrmsPerBlck = 15;
        case 4
            S_ImgPrms.NFrmsPerBlck = 30;
    end
    
    % read odor stim info
    strListOdrID = char(get(S_PnlCtrls.hPopOdrID, 'String'));      
    S_OdrPrms.valOdrID = get(S_PnlCtrls.hPopOdrID,'Value');
    S_OdrPrms.strOdrID = strListOdrID(S_OdrPrms.valOdrID,:);
    %if S_OdrPrms.valOdrID == 1
    %S_OdrPrms.arrVlvCtrl(S_OdrPrms.valOdrID+2) = 1;
    if S_OdrPrms.valOdrID ~= 1
        S_OdrPrms.arrVlvCtrl(3) = 1;
        S_OdrPrms.arrVlvCtrl(S_OdrPrms.valOdrID+2) = 1;
    end

    % calcs for basic acquisition params
    S_OdrPrms.DurPre = str2double(get(S_PnlCtrls.hTxtDurPre,'String'));
    S_OdrPrms.DurExch = str2double(get(S_PnlCtrls.hTxtDurExch,'String'));
    S_OdrPrms.DurOdr = str2double(get(S_PnlCtrls.hTxtDurOdr,'String'));
    S_OdrPrms.DurMap = str2double(get(S_PnlCtrls.hTxtDurMap,'String'));
    S_OdrPrms.TOnExch = S_OdrPrms.DurPre-S_OdrPrms.DurExch;
    S_OdrPrms.TOffOdr = S_OdrPrms.DurPre+S_OdrPrms.DurOdr;
    S_OdrPrms.TTot = S_OdrPrms.DurPre+S_OdrPrms.DurMap;
    S_ImgPrms.NFrms = S_ImgPrms.FrmRtHz * S_OdrPrms.TTot;
    %nfrms = S_ImgPrms.NFrms
    S_ImgPrms.NBlcks = S_ImgPrms.NFrms / S_ImgPrms.NFrmsPerBlck;
    
    % panel for text progress output
    hPanProg = figure;
    set (hPanProg, 'Position',[100,900,300,70], ...
                   'Name','    Progress ','MenuBar','none');
    S_PnlCtrls.hTxtProg = uicontrol('Style','text','String','initializing...',...
                         'FontSize',12,'Position',[40,25,220,22]);   
    
    S_DspPrms.SeqNFrms = S_ImgPrms.NBlcks;
    set(S_PnlCtrls.hTxtNumFrms,'String',strcat('   /   ',num2str(S_ImgPrms.NBlcks)));
    set(S_PnlCtrls.hSldFrmNum,'Max',S_ImgPrms.NBlcks,...
                   'SliderStep',[1/(S_ImgPrms.NBlcks-1) 5/(S_ImgPrms.NBlcks-1)]);
    
    % create video input object and set properties
    vidNI = videoinput('ni',1);
    vidNI.FramesPerTrigger = S_ImgPrms.NFrms;
    vidNI.FrameGrabInterval = 1;
    
    % create timer objects to control odor delivery
    tmrTOnExch = timer;
    tmrTOnExch.StartDelay = S_OdrPrms.TOnExch;
    tmrTOnExch.TimerFcn = @(x,y)fcnTmrOdrExch;
    tmrTOnOdr = timer;
    tmrTOnOdr.StartDelay = S_OdrPrms.DurPre;
    tmrTOnOdr.TimerFcn = @(x,y)fcnTmrOdrOn; 
    tmrTOffOdr = timer;
    tmrTOffOdr.StartDelay = S_OdrPrms.TOffOdr;
    tmrTOffOdr.TimerFcn = @(x,y)fcnTmrOdrOff;
    tmrTOnCln = timer;
    tmrTOnCln.StartDelay = S_OdrPrms.TOffOdr+5;
    tmrTOnCln.TimerFcn = @(x,y)fcnTmrClnOn;
    tmrTOffCln = timer;
    tmrTOffCln.StartDelay = S_OdrPrms.TOffOdr+13;
    tmrTOffCln.TimerFcn = @(x,y)fcnTmrClnOff; 
    tmrArrAll = [tmrTOnExch tmrTOnOdr tmrTOffOdr tmrTOnCln tmrTOffCln];
    
    % create arrays for holding frame and image data etc
    arrBlckSeq = zeros (S_ImgPrms.ImgSizX,S_ImgPrms.ImgSizY,...
                        S_ImgPrms.NBlcks,'int16');
    arrFrmTs = zeros(S_ImgPrms.NBlcks,1,'single');
    
    % progress update
    set(S_PnlCtrls.hTxtProg,'String','starting acquisition');
    drawnow 
    
    % start video acquisition to image buffer and timers for odor valves
    start (vidNI);
    start (tmrArrAll);
    
    wait (vidNI,40);
    
    %while(1);
    %    get(vidNI,'FramesAvailable')
    
    % pull frame data from img buffer during acquisition
    for ii = 1:1:S_ImgPrms.NBlcks;
        %while (1) 
        %    vFrmsAvl = get(vidNI,'FramesAvailable');
        %    if (vFrmsAvl>=S_ImgPrms.NFrmsPerBlck);
        %        break
        %    end
        %end
        [arrBlckFrms, arrFrmTs] = getdata(vidNI,S_ImgPrms.NFrmsPerBlck);
        arrBlckSeq(:,:,ii) = sum(arrBlckFrms,4)/S_ImgPrms.NFrmsPerBlck;
    end
    
    % progress update
    set(S_PnlCtrls.hTxtProg,'String','finished acquisition'); 
    drawnow 
    pause (0.2);
    
    %==  map analysis
    
    % progress update
    set(S_PnlCtrls.hTxtProg,'String','starting analysis');
    drawnow 
    pause (0.2);
    
    % convert to single precision for calcs
    arrBlckSeq = single(arrBlckSeq);
    
    % calculate R0 frame for subtraction
    valNBlcksR0 = S_OdrPrms.DurPre*(S_ImgPrms.FrmRtHz/S_ImgPrms.NFrmsPerBlck);
    arrImgR0 = sum(arrBlckSeq(:,:,1:valNBlcksR0),3)/valNBlcksR0;
    
    % divide image series by R0 image to convert to fractional change   
    S_ImgDat.arrMapSeq = zeros(S_ImgPrms.ImgSizX,S_ImgPrms.ImgSizY,...
                     S_ImgPrms.NBlcks,'single');
    arrTmp = zeros(S_ImgPrms.ImgSizX,S_ImgPrms.ImgSizY,'single');
    for ii = 1:S_ImgPrms.NBlcks
        arrTmp(:,:) = arrBlckSeq(:,:,ii);
        arrTmp(:,:) = arrTmp(:,:) ./ arrImgR0(:,:);
        S_ImgDat.arrMapSeq(:,:,ii) = arrTmp(:,:);
    end
    
    % calculate final average DRR image from post-stim time period
    valBlckStart = ((S_OdrPrms.DurPre+5)*(S_ImgPrms.FrmRtHz/S_ImgPrms.NFrmsPerBlck));
    valNumDRRBlcks = (S_OdrPrms.DurMap-5)*(S_ImgPrms.FrmRtHz/S_ImgPrms.NFrmsPerBlck);
    valBlckEnd = valBlckStart+valNumDRRBlcks-1;
    S_ImgDat.arrMapImg = sum(S_ImgDat.arrMapSeq(:,:,valBlckStart:valBlckEnd),3)/valNumDRRBlcks;
    
    % calculate filtered image
    % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!add calculation
    % here!!!!!!!!!!!!!!!!!!!!!
    S_ImgDat.arrMapImgFlt = S_ImgDat.arrMapImg;
    
    % show map data in figure window
    if get(S_PnlCtrls.hChkMedFlt,'Value')
        set(S_PnlCtrls.hImgMap,'CData',S_ImgDat.arrMapImgFlt);
    else
        set(S_PnlCtrls.hImgMap,'CData',S_ImgDat.arrMapImg);
    end
    S_ImgDat.arrMapSeqFrm = S_ImgDat.arrMapSeq(:,:,valNumDRRBlcks);
    set(S_PnlCtrls.hImgSeqFrm,'CData',S_ImgDat.arrMapSeqFrm);
    
    % progress update 
    set(S_PnlCtrls.hTxtProg,'String','done analysis');
    drawnow 
    pause (0.3);
    wait(tmrTOffCln);
    
    % clean up
    delete (tmrTOnExch);
    delete (tmrTOnOdr);
    delete (tmrTOffOdr);
    delete (tmrTOnCln);
    delete (tmrTOffCln);
    flushdata (vidNI,'all');
    delete (vidNI);
    clear vidNI;
    close(hPanProg);
    
    % set file flags to indicate new data
    S_FilePrms.FlgAcq = 1;
    S_FilePrms.FlgSav = 0;
    
    assignin('base','arrMapImg',S_ImgDat.arrMapImg);
    assignin('base','arrMapSeq',S_ImgDat.arrMapSeq);
    
end

 
%================================================================= 
function fcnTmrOdrExch(~,~)
    global sessNI
    global S_PnlCtrls
    global S_OdrPrms
    
    S_OdrPrms.arrVlvCtrl(1) = 1;
    %aa = S_OdrPrms.arrVlvCtrl;
    %disp('-----------')
    %disp('odor exch')
    %disp(aa);
    sessNI.outputSingleScan(S_OdrPrms.arrVlvCtrl)
    set(S_PnlCtrls.hTxtProg,'String','odor exchange');
    drawnow
end
%================================================================= 
function fcnTmrOdrOn(~,~)
    global sessNI
    global S_PnlCtrls
    global S_OdrPrms
    S_OdrPrms.arrVlvCtrl(2) = 1;
    %aa = S_OdrPrms.arrVlvCtrl;
    %disp('odor on')
    %disp(aa);
    sessNI.outputSingleScan(S_OdrPrms.arrVlvCtrl)
    set(S_PnlCtrls.hTxtProg,'String','odor on');
    drawnow
end
%================================================================= 
function fcnTmrOdrOff(~,~)
    global sessNI
    global S_PnlCtrls
    global S_OdrPrms
    S_OdrPrms.arrVlvCtrl(2:8) = 0;
    %S_OdrPrms.arrVlvCtrl(3) = 1;
    %aa = S_OdrPrms.arrVlvCtrl;
    %disp('odor off')
    %disp(aa);
    sessNI.outputSingleScan(S_OdrPrms.arrVlvCtrl)
    set(S_PnlCtrls.hTxtProg,'String','odor off');
    drawnow
end
%================================================================= 
function fcnTmrClnOn(~,~)
    global sessNI
    global S_PnlCtrls
    global S_OdrPrms
    S_OdrPrms.arrVlvCtrl(1:2) = 1;
    %aa = S_OdrPrms.arrVlvCtrl;
    %disp('cln on')
    %disp(aa);
    sessNI.outputSingleScan(S_OdrPrms.arrVlvCtrl)
    set(S_PnlCtrls.hTxtProg,'String','flushing lines');
    drawnow
end
%================================================================= 
function fcnTmrClnOff(~,~)
    global sessNI
    global S_PnlCtrls
    global S_OdrPrms
    S_OdrPrms.arrVlvCtrl(1:3) = 0;
    %aa = S_OdrPrms.arrVlvCtrl;
    %disp('cln off')
    %disp(aa)
    %disp('-----------')
    %disp(' ')
    sessNI.outputSingleScan(S_OdrPrms.arrVlvCtrl)
    set(S_PnlCtrls.hTxtProg,'String','done');
    drawnow
end