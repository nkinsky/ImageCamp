 function fcnIntrinsicVisGUI_30
    
    % global structures to hold display & acq info
    global S_PnlCtrls
    global S_OdrPrms
    global S_DspPrms
    global S_ImgPrms
    global S_ImgDat
    global S_FilePrms
    % image acquisition session
    global sessNI
    % stim & acq control UIs
    global hCkbxHiPFlt
    global hCkbxMedFlt
    
    % initialize acq params    
    S_ImgPrms.ImgSizX = 512;
    S_ImgPrms.ImgSizY = 512;
    S_ImgPrms.FrmRtHz = 60;
    S_ImgPrms.NFrmsPerBlck = 15;
    S_ImgDat.arrMapImg = ones(S_ImgPrms.ImgSizX,S_ImgPrms.ImgSizY);
    S_ImgDat.arrMapSeq = ones(S_ImgPrms.ImgSizX,S_ImgPrms.ImgSizY,2);
    S_ImgDat.arrMapSeqFrm = ones(S_ImgPrms.ImgSizX,S_ImgPrms.ImgSizY);
    
    S_OdrPrms.DurPre = 4;
    S_OdrPrms.DurExch = 3;
    S_OdrPrms.DurOdr = 5;
    S_OdrPrms.DurMap = 8;
    S_OdrPrms.DurCln = 10;
    S_OdrPrms.arrVlvCtrl = ([0 0 0 0 0 0 0 0]);
    
    S_DspPrms.arrLims = [0.994 1.002];
    S_DspPrms.SeqFrm = 1;
    S_DspPrms.SeqNFrms = 2;
    
    S_FilePrms.TrlNumVal = 1;
    S_FilePrms.TrlNumStr = '01';
    S_FilePrms.FlgSav = 0;
    S_FilePrms.FlgAcq = 0;
    
    strOdorList = {'_01_blank','_02_blank_minoil',...
    	'_03_amyl acetate','_04_methyl salicylate',...
    	'_05_(-)_carvone','_06_isoeugenol',...
        '_07_1-pentanol','_08_guaiacol',...
     	'_09_eugenol','_10_methyl_isoeugenol',...
     	'_11_benzaldehyde','_12_methyl_benzoate'...
      	'_13_allyl_methoxybenz','_14_2-hexanone',...
       	'_15_methyl_valerate','_16_butyl_acetate',...
      	'_17_2methyl_butyrald'};
    
    % set up GUI panel
    S_PnlCtrls.hGUI = figure('Position',[25,100,270,900], ...
                      'MenuBar', 'none', ...
                      'Name','Acq Controls');
                  
    % add controls - buttons, pulldowns, etc
    vGuiLft1 = 30;
    vGuiLft2 = 110;
    vGuiLft3 = 200;
    vGuiTop0 = 815;
    vGuiTop1 = 675;
    vGuiTop2 = 565;
    vGuiTop3 = 290;
    vGuiTop4 = 170;
    vGuiTop5 = 60;
    % controls for imaging parameters
    hTxtImgGrpLbl = uicontrol('Style','text',...
                              'String','camera settings:',...
                              'BackgroundColor',([0.7 0.7 0.7]),...
                              'Position',[vGuiLft1,vGuiTop0+25,210,16]);  
    hTxtImgSizLbl = uicontrol('Style','text',...
                              'String','image size:',...
                              'Position',[vGuiLft1,vGuiTop0,70,16]);  
    S_PnlCtrls.hPopImgSiz = uicontrol('Style','popup',...
                'String','          512 x 512|         1024 x 1024',...
                'Value',1,...
                'Position',[vGuiLft2,vGuiTop0+2,130,18]);
    hTxtFrmRateLbl = uicontrol('Style','text',...
                               'String','frame rate:',...
                               'Position',[vGuiLft1,vGuiTop0-25,70,16]);  
    S_PnlCtrls.hPopFrmRtHz = uicontrol('Style','popup',...
                          'String','          30 Hz|          60 Hz',...
                          'Value',2,...
                          'Position',[vGuiLft2,vGuiTop0-23,130,18]);
    hTxtFrmPerBlckLbl = uicontrol('Style','text',...
                          'String','average:',...
                          'Position',[vGuiLft1,vGuiTop0-50,70,16]);
    strLstFrmPerBlck = strcat('          5 frames|',...
                              '         10 frames|',...
                              '         15 frames|',...
                              '         30 frames');
    S_PnlCtrls.hPopFrmPerBlck = uicontrol('Style','popup',...
                          'String',strLstFrmPerBlck,...
                          'Value',1,...
                          'Position',[vGuiLft2,vGuiTop0-48,130,18]);
    % controls for focus and ref image
    hTxtPrepGrpLbl = uicontrol('Style','text',...
                              'String','imaging setup:',...
                              'BackgroundColor',([0.7 0.7 0.7]),...
                              'Position',[vGuiLft1,vGuiTop1+37,210,16]);                                    
    hBtnFcs = uicontrol('Style','pushbutton',...
                          'String','focus',...
                          'Position',[vGuiLft1,vGuiTop1,210,30],...
                          'Callback',{@fcnIntrinsicVisFcs_30});
    hBtnRefImg = uicontrol('Style','pushbutton',...
                          'String','reference image',...
                          'Position',[vGuiLft1,vGuiTop1-35,210,30],...
                          'Callback',{@fcnIntrinsicVisRefImg_30}); 
    % controls for stim settings
    hTxtStimGrpLbl = uicontrol('Style','text',...
                              'String','stimulus settings:',...
                              'BackgroundColor',([0.7 0.7 0.7]),...
                              'Position',[vGuiLft1,vGuiTop2+25,210,16]);                     
    hTxtTrlNumLbl = uicontrol('Style','text',...
                          'String','trial #:',...
                          'Position',[vGuiLft1,vGuiTop2,70,16]);  
    S_PnlCtrls.hTxtTrlNum = uicontrol('Style','text',...
                          'String','01',...
                          'Position',[vGuiLft2,vGuiTop2,85,16]);         
    hBtnTrlDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop2,18,18],...
                          'Callback',{@fcnBtnTrlDec});
    hBtnTrlInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop2,18,18],...
                          'Callback',{@fcnBtnTrlInc}); 
    hTxtOdrIDLbl = uicontrol('Style','text',...
                          'String','odor #:',...
                          'Position',[vGuiLft1,vGuiTop2-25,70,16]);                   
    S_PnlCtrls.hPopOdrID = uicontrol('Style','popupmenu',...
                          'String', strOdorList,...
                          'Position',[vGuiLft2,vGuiTop2-26,130,20]);
    % controls for prestimulus period               
    hTxtDurPreLbl = uicontrol('Style','text',...
                          'String','pre (sec):',...
                          'Position',[vGuiLft1,vGuiTop2-50,70,16]);  
    S_PnlCtrls.hTxtDurPre = uicontrol('Style','text',...
                          'String','4.0',...
                          'Position',[vGuiLft2,vGuiTop2-50,85,16]);         
    hBtnDurPreDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop2-51,18,18],...
                          'Callback',{@fcnBtnDurPreDec});
    hBtnDurPreInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop2-51,18,18],...
                          'Callback',{@fcnBtnDurPreInc});
    % controls for timing of odor exchange period
    hTxtDurExchLbl = uicontrol('Style','text',...
                          'String','exch (sec):',...
                          'Position',[vGuiLft1,vGuiTop2-75,70,16]);  
    S_PnlCtrls.hTxtDurExch = uicontrol('Style','text',...
                          'String','3.0',...
                          'Position',[vGuiLft2,vGuiTop2-75,85,16]);         
    hBtnDurExchDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop2-76,18,18],...
                          'Callback',{@fcnBtnDurExchDec});
    hBtnDurExchInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop2-76,18,18],...
                          'Callback',{@fcnBtnDurExchInc});  
    % controls for duration of odor presentation                 
    hTxtDurOdrLbl = uicontrol('Style','text',...
                          'String','odor (sec):',...
                          'Position',[vGuiLft1,vGuiTop2-100,70,16]);  
    S_PnlCtrls.hTxtDurOdr = uicontrol('Style','text',...
                          'String','5.0',...
                          'Position',[vGuiLft2,vGuiTop2-100,85,16]);         
    hBtnDurOdrDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop2-101,18,18],...
                          'Callback',{@fcnBtnDurOdrDec});
    hBtnDurOdrInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop2-101,18,18],...
                          'Callback',{@fcnBtnDurOdrInc});
    % controls for total post acquisition time                   
    hTxtDurMapLbl = uicontrol('Style','text',...
                          'String','map (sec):',...
                          'Position',[vGuiLft1,vGuiTop2-125,70,16]);  
    S_PnlCtrls.hTxtDurMap = uicontrol('Style','text',...
                          'String','8.0',...
                          'Position',[vGuiLft2,vGuiTop2-125,85,16]);         
    hBtnDurMapDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop2-126,18,18],...
                          'Callback',{@fcnBtnDurMapDec});
    hBtnDurMapInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop2-126,18,18],...
                          'Callback',{@fcnBtnDurMapInc});
    hBtnMapAcq = uicontrol('Style','pushbutton',...
                          'String','acquire new map',...
                          'Position',[vGuiLft1,vGuiTop2-165,210,30],...
                          'Callback',{@fcnIntrinsicVisAcq_30});                       
    hBtnMapSav = uicontrol('Style','pushbutton',...
                          'String','save current map',...
                          'Position',[vGuiLft1,vGuiTop2-200,210,30],...
                          'Callback',{@fcnBtnMapSvClbk});
    % controls for cleaning lines
    hTxtClnGrpLbl = uicontrol('Style','text',...
                              'String','blank airflow:',...
                              'BackgroundColor',([0.7 0.7 0.7]),...
                              'Position',[vGuiLft1,vGuiTop3+25,210,16]); 
    hTxtDurClnLbl = uicontrol('Style','text',...
                          'String','clean (sec):',...
                          'Position',[vGuiLft1,vGuiTop3,70,16]);  
    S_PnlCtrls.hTxtDurCln = uicontrol('Style','text',...
                          'String','10',...
                          'Position',[vGuiLft2,vGuiTop3,85,16]);         
    hBtnDurClnDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop3,18,18],...
                          'Callback',{@fcnBtnDurClnDec});
    hBtnDurClnInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop3,18,18],...
                          'Callback',{@fcnBtnDurClnInc});
    hBtnCln = uicontrol('Style','pushbutton',...
                          'String','clean step',...
                          'Position',[vGuiLft1,vGuiTop3-40,210,30],...
                          'Callback',{@fcnBtnClnLnsClbk});             
    % controls for setting lower display limits
    hTxtDspGrpLbl = uicontrol('Style','text',...
                              'String','display limits:',...
                              'BackgroundColor',([0.7 0.7 0.7]),...
                              'Position',[vGuiLft1,vGuiTop4+25,210,16]); 
    hTxtDspLimLoLbl = uicontrol('Style','text',...
                          'String','map disp lo:',...
                          'Position',[vGuiLft1,vGuiTop4,70,16]);  
    S_PnlCtrls.hTxtDspLimLo = uicontrol('Style','text',...
                          'String','0.994',...
                          'Position',[vGuiLft2,vGuiTop4,85,16]);         
    hTxtDspLimLoDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop4,18,18],...
                          'Callback',{@fcnBtnDspLimLoDec});
    hTxtDspLimLoInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop4,18,18],...
                          'Callback',{@fcnBtnDspLimLoInc});
    % controls for setting upper display limits
    hTxtDspLimHiLbl = uicontrol('Style','text',...
                          'String','map disp hi:',...
                          'Position',[vGuiLft1,vGuiTop4-20,70,16]);  
    S_PnlCtrls.hTxtDspLimHi = uicontrol('Style','text',...
                          'String','1.002',...
                          'Position',[vGuiLft2,vGuiTop4-20,85,16]);         
    hTxtDspLimHiDec = uicontrol('Style','pushbutton',...
                          'String','-',...
                          'Position',[vGuiLft3,vGuiTop4-20,18,18],...
                          'Callback',{@fcnBtnDspLimHiDec});
    hTxtDspLimHiInc = uicontrol('Style','pushbutton',...
                          'String','+',...
                          'Position',[vGuiLft3+20,vGuiTop4-20,18,18],...
                          'Callback',{@fcnBtnDspLimHiInc});
    % load in previous data to review
    hTxtDspGrpLbl = uicontrol('Style','text',...
                              'String','review data:',...
                              'BackgroundColor',([0.7 0.7 0.7]),...
                              'Position',[vGuiLft1,vGuiTop5+37,210,16]); 
    hBtnLoadTrial = uicontrol('Style','pushbutton',...
                          'String','load & review trial',...
                          'Position',[vGuiLft1,vGuiTop5,210,30],...
                          'Callback',{@fcnBtnLoadTrial});     
                      
%     hBtnMapAnlyz = uicontrol('Style','pushbutton',...
%                           'String','load & review',...
%                           'Position',[vGuiLft1,105,210,30],...
%                           'Callback',{@fcnBtnLoadTrial});                  
%     hBtnMapView = uicontrol('Style','pushbutton',...
%                           'String','view averaged maps',...
%                           'Position',[vGuiLft1,65,210,30],...
%                           'Callback',{@fcnEvaluateMapAverage});                   
              
    set(S_PnlCtrls.hGUI,'Visible','on');
    
    % figure panel for displaying final map
    S_PnlCtrls.hFigMap = figure;
    set (S_PnlCtrls.hFigMap, 'Position',[320,350,650,650],...
                  'MenuBar', 'none', ...
                  'Color', 'k', ...
                  'Colormap', bone(256),...
                  'Name','Averaged Map');
    S_PnlCtrls.hImgMap = image(S_ImgDat.arrMapImg);
    set(S_PnlCtrls.hImgMap,'CDataMapping','scaled');
    S_PnlCtrls.hAxesMap = gca;
    set(S_PnlCtrls.hAxesMap,'Position',[0.1,0.1,0.8,0.8]);
    axis off;
    axis image;
    uicontrol('Style','Text', 'Position', [80 22 120 16], ...
              'ForegroundColor', 'white', ...
              'BackgroundColor', 'black', ...
              'String', '   high-pass filter :');
    S_PnlCtrls.hChkHiPFlt = uicontrol('Style','Checkbox', 'Position', [210 22 16 16]);
    uicontrol('Style','Text', 'Position', [230 22 120 16], ...
              'ForegroundColor', 'white', ...
              'BackgroundColor', 'black', ...
              'String', '   median filter (3) :');
    S_PnlCtrls.hChkMedFlt = uicontrol('Style','Checkbox', 'Position', [340 22 16 16]);
    
    % figure panel for displaying frame by frame sequence
    S_PnlCtrls.hFigSeqFrm = figure;
    set (S_PnlCtrls.hFigSeqFrm,'Position',[995,350,650,650], ...
                    'MenuBar', 'none', ...
                    'Color', 'k', ...
                    'Colormap', bone(256), ...
                    'Name','Full Image Sequence');
    S_PnlCtrls.hImgSeqFrm = image(S_ImgDat.arrMapSeqFrm);
    set(S_PnlCtrls.hImgSeqFrm,'CDataMapping','scaled');
    S_PnlCtrls.hAxesSeqFrm = gca;
    set(S_PnlCtrls.hAxesSeqFrm,'Position',[0.1,0.1,0.8,0.8]);
    axis off;
    axis image;
    uicontrol('Style','text', 'Position', [80 22 40 16], ...
              'ForegroundColor', 'white', ...
              'BackgroundColor', 'black', ...
              'String', '   frame   :');
    S_PnlCtrls.hTxtFrmNum = uicontrol('Style','text', 'Position', [120 22 30 16], ...
                           'ForegroundColor', 'white', ...
                           'BackgroundColor', 'black', ...
                           'String', '    1  ');
    S_PnlCtrls.hTxtNumFrms = uicontrol('Style','text', 'Position', [150 22 40 16], ...
                            'ForegroundColor', 'white', ...
                            'BackgroundColor', 'black', ...
                            'String', '   /   2 ');      
    S_PnlCtrls.hSldFrmNum = uicontrol('Style','slider', ...
                           'Position', [250 20 300 20], ...
                           'Min',1,'Max',2, ...
                           'Value',1,'SliderStep',[1 1], ...
                           'Callback', @fcnSldFrmUpd);
    
    %set contrast
    fcnBtnSetDspLims;
    
    % set up NI sesssion for input and output
    fcnIntrinsicVisNIsetup_30;
    
end

%==================================================================
function fcnBtnClnLnsClbk(~,~)

    global S_PnlCtrls
    global sessNI
    
    % read duration info from popup
    figure(S_PnlCtrls.hGUI);
    strDurCln = get(S_PnlCtrls.hTxtDurCln, 'String');      
    valDurCln = str2num(strDurCln);
    
    % operate valves with blank stim to remove residual odor
    sessNI.outputSingleScan([1 0 0 0 0 0 0 0])
    pause(valDurCln/5);
    sessNI.outputSingleScan([1 1 0 0 0 0 0 0])
    pause(3*valDurCln/5);
    sessNI.outputSingleScan([0 0 0 0 0 0 0 0])
    
end

%=====================================================================
function fcnBtnMapSvClbk(~,~)
    
    global S_PnlCtrls
    global S_ImgDat
    global S_OdrPrms
    global S_ImgPrms
    global S_DspPrms
    global S_FilePrms
    
    if (S_FilePrms.FlgSav==1)
        return
    end
    
    % panel for text progress output
    hPanProg = figure;
    set (hPanProg, 'Position',[100,900,300,70], ...
                   'Name','    Progress ','MenuBar','none');
    hTxtProg = uicontrol('Style','text','String','saving...',...
                         'FontSize',12,'Position',[40,25,220,22]); 

    % bring control fig window to front
    %figure(S_PnlCtrls.hGUI);
    
    % read odor ID info from popup
    strListOdorID = char(get(S_PnlCtrls.hPopOdrID, 'String')) ;      
    valOdorID = get(S_PnlCtrls.hPopOdrID,'Value');
    strOdorID = strListOdorID(valOdorID,:);
    
    % change to odor-specific directory to hold data;
    % create if doesnt' exist
    strNewFldr = strcat('./od', strOdorID);
    if (isdir(strNewFldr));
        strOldFldr = cd(strNewFldr);
    else
        mkdir(strNewFldr);
        strOldFldr = cd(strNewFldr); 
    end
    
    % create filename and save
    strFilNam = strcat('od',strOdorID(2:3),'tr',S_FilePrms.TrlNumStr);
    save (strFilNam, 'S_ImgDat','S_OdrPrms','S_ImgPrms');
    
    % return to original main data folder
    cd (strOldFldr)
    
    % increment trial number and update    
    S_FilePrms.TrlNumVal = S_FilePrms.TrlNumVal+1;
    S_FilePrms.TrlNumStr = num2str(S_FilePrms.TrlNumVal);
    if (numel(S_FilePrms.TrlNumStr)==1)
        S_FilePrms.TrlNumStr = strcat('0',S_FilePrms.TrlNumStr);
    end
    S_FilePrms.FlgSav = 1;
    set (S_PnlCtrls.hTxtTrlNum, 'String', S_FilePrms.TrlNumStr)
    
    % clean up
    close(hPanProg);
    
end
  
%=====================================================================
function fcnBtnLoadTrial(~,~)
    global S_PnlCtrls
    global S_ImgDat
    global S_ImgPrms
    global S_DspPrms
    
    % user selects filename
    [strFilNam,strPthNam] = uigetfile('*.mat','Select data file:');
    strFilNamFull = strcat(strPthNam,strFilNam);
    % load _only_ data from 
    load(strFilNamFull,'S_ImgDat')
    %load(strFilNamFull,'arrMapImg','arrMapSeq');
    %load(strFilNamFull,'arrMapSeq');
    %S_ImgDat.arrMapImg = double(arrMapImg);
    %S_ImgDat.arrMapSeq = double(arrMapSeq);
    % show map data in figure window
    %if get(hCbxDspFlt,'Value')
    %    set(S_PnlCtrls.hImgMap,'CData',S_ImgDat.arrMapImgFlt);
    %else
    %    set(S_PnlCtrls.hImgMap,'CData',S_ImgDat.arrMapImg);
    %end
    %S_ImgDat.arrMapSeqFrm = S_ImgDat.arrMapSeq(:,:,valNumDRRBlcks);
    set(S_PnlCtrls.hImgMap,'CData',S_ImgDat.arrMapImg);
    %set(S_PnlCtrls.hImgSeqFrm,'CData',S_ImgDat.arrMapSeqFrm);
    
    % update controls
    %S_DspPrms.SeqNFrms = S_ImgPrms.NBlcks;
    S_DspPrms.SeqNFrms = size(S_ImgDat.arrMapSeq,3);
    S_ImgPrms.NBlcks = size(S_ImgDat.arrMapSeq,3);
    set(S_PnlCtrls.hTxtNumFrms,'String',strcat('   /   ',num2str(S_ImgPrms.NBlcks)));
    set(S_PnlCtrls.hSldFrmNum,'Max',S_ImgPrms.NBlcks,...
                   'SliderStep',[1/(S_ImgPrms.NBlcks-1) 5/(S_ImgPrms.NBlcks-1)]);
    
    fcnSldFrmUpd
    
end

%=====================================================================
function fcnApplyFilts(~,~)

    % add later...

end

%=====================================================================
function [arrImgFltHi] = fcnApply2DGssFlt(arrImgRaw)
    
    global S_ImgPrms
    global S_PnlCtrls
    global S_ImgDat
    global S_DspPrms
    
    % read filter settings from GUI
    %varSigma = (S_ImgPrms.ImgSizX/5);
    varSigma = 100;
    
    % create 2D gaussian distribution to convolve
    varGaussW2 = 120;
    arrMu = [0 0];
    arrSigma = [varSigma 0; 0 varSigma];
    arrx1 = -varGaussW2:1:varGaussW2; 
    arrx2 = -varGaussW2:1:varGaussW2;
    [X1,X2] = meshgrid(arrx1,arrx2);
    F = mvnpdf([X1(:) X2(:)],arrMu,arrSigma);
    F = reshape(F,length(arrx2),length(arrx1));
    
    % apply gaussian filtering
    arrImgFltLo = imfilter (arrImgRaw,F,'conv');
    arrImgFltHi = (arrImgRaw-arrImgFltLo)+1;
    
    % update image display
    figure;
    imshow(arrImgFltLo);
    figure;
    imshow(arrImgFltHi);
    
    %set (S_PnlCtrls.hImgMap,'CData',arrImg2FltLo);
    
    
    % call median filter routine to update downstream images
    %   (will eventually call display update as well)
    %fcnApplyMedFlt2;
    
end

%==================================================================
function fcnBtnSetDspLims(~,~)

    global S_PnlCtrls
    global S_DspPrms
    
    %S_DspPrms.arrLims = [varDispLimLoVal, varDispLimHiVal];   
    % apply to map display figure
    figure(S_PnlCtrls.hFigMap);
    set(gca,'CLim', S_DspPrms.arrLims);
    figure(S_PnlCtrls.hFigSeqFrm);
    set(gca,'CLim', S_DspPrms.arrLims);
    
end
%==================================================================
function fcnSldFrmUpd(~,~)
    global S_PnlCtrls
    global S_DspPrms
    global S_ImgDat
    % refresh image sequence window using value from slider
    S_DspPrms.SeqFrm = get(S_PnlCtrls.hSldFrmNum,'Value');
    S_DspPrms.SeqFrm = round(S_DspPrms.SeqFrm);
    set(S_PnlCtrls.hSldFrmNum,'Value',S_DspPrms.SeqFrm);
    S_ImgDat.arrMapSeqFrm = S_ImgDat.arrMapSeq(:,:,S_DspPrms.SeqFrm);
    set(S_PnlCtrls.hImgSeqFrm,'CData',S_ImgDat.arrMapSeqFrm);
    set(S_PnlCtrls.hTxtFrmNum,'String',num2str(S_DspPrms.SeqFrm));
end
%==================================================================
function fcnBtnTrlDec(~,~)
    global S_FilePrms
    global S_PnlCtrls
    % decrement trial number & refresh
    S_FilePrms.TrlNumVal = S_FilePrms.TrlNumVal-1;
    if S_FilePrms.TrlNumVal<1
        S_FilePrms.TrlNumVal=1;
    end
    S_FilePrms.TrlNumStr = num2str(S_FilePrms.TrlNumVal);
    if numel(S_FilePrms.TrlNumStr)==1
        S_FilePrms.TrlNumStr=strcat('0',S_FilePrms.TrlNumStr);
    end
    set (S_PnlCtrls.hTxtTrlNum,'String',S_FilePrms.TrlNumStr)
end
%==================================================================
function fcnBtnTrlInc(~,~)
    global S_FilePrms
    global S_PnlCtrls
    % increment trial number & refresh
    S_FilePrms.TrlNumVal = S_FilePrms.TrlNumVal+1;
    S_FilePrms.TrlNumStr = num2str(S_FilePrms.TrlNumVal);
    if numel(S_FilePrms.TrlNumStr)==1
        S_FilePrms.TrlNumStr=strcat('0',S_FilePrms.TrlNumStr);
    end
    set (S_PnlCtrls.hTxtTrlNum,'String',S_FilePrms.TrlNumStr)
end
%==================================================================
function fcnBtnDurPreDec(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % decrement duration of 'pre' odor phase
    S_OdrPrms.DurPre = S_OdrPrms.DurPre-0.5;
    if S_OdrPrms.DurPre<3
        S_OdrPrms.DurPre=3;
    elseif S_OdrPrms.DurPre<S_OdrPrms.DurExch
        S_OdrPrms.DurPre=S_OdrPrms.DurExch;
    end
    strTmp = num2str(S_OdrPrms.DurPre);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurPre,'String',strTmp)
end
%==================================================================
function fcnBtnDurPreInc(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % increment duration of 'pre' odor phase and refresh
    S_OdrPrms.DurPre = S_OdrPrms.DurPre+0.5;
    if S_OdrPrms.DurPre>10
        S_OdrPrms.DurPre=10;
    end
    strTmp = num2str(S_OdrPrms.DurPre);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurPre,'String',strTmp)
end
%==================================================================
function fcnBtnDurExchDec(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % decrement duration of 'exchange' odor phase and refresh
    S_OdrPrms.DurExch = S_OdrPrms.DurExch-0.5;
    if S_OdrPrms.DurExch<1.5
        S_OdrPrms.DurExch=1.5;
    end
    strTmp = num2str(S_OdrPrms.DurExch);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurExch,'String',strTmp)
end
%==================================================================
function fcnBtnDurExchInc(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % increment duration of 'exchange' odor phase and refresh
    S_OdrPrms.DurExch = S_OdrPrms.DurExch+0.5;
    if S_OdrPrms.DurExch>6
        S_OdrPrms.DurExch=6;
    elseif S_OdrPrms.DurExch>S_OdrPrms.DurPre
        S_OdrPrms.DurExch=S_OdrPrms.DurPre;
    end
    strTmp = num2str(S_OdrPrms.DurExch);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurExch,'String',strTmp)
end
%==================================================================
function fcnBtnDurOdrDec(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % decrement duration of odor presentation period and refresh
    S_OdrPrms.DurOdr = S_OdrPrms.DurOdr-0.5;
    if S_OdrPrms.DurOdr<1
        S_OdrPrms.DurOdr=1;
    end
    strTmp = num2str(S_OdrPrms.DurOdr);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurOdr,'String',strTmp)
end
%==================================================================
function fcnBtnDurOdrInc(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % increment duration of odor presentation period and refresh
    S_OdrPrms.DurOdr = S_OdrPrms.DurOdr+0.5;
    if S_OdrPrms.DurOdr>20
        S_OdrPrms.DurOdr=20;
    elseif S_OdrPrms.DurOdr>S_OdrPrms.DurMap
        S_OdrPrms.DurOdr=S_OdrPrms.DurMap;
    end
    strTmp = num2str(S_OdrPrms.DurOdr);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurOdr,'String',strTmp)
end
%==================================================================
function fcnBtnDurMapDec(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % decremebt duration of map calculation period and refresh
    S_OdrPrms.DurMap = S_OdrPrms.DurMap-0.5;
    if S_OdrPrms.DurMap<3
        S_OdrPrms.DurMap=3;
    elseif S_OdrPrms.DurMap<S_OdrPrms.DurOdr
        S_OdrPrms.DurMap=S_OdrPrms.DurOdr;
    end
    strTmp = num2str(S_OdrPrms.DurMap);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurMap,'String',strTmp)
end
%==================================================================
function fcnBtnDurMapInc(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % increment duration of map calculation period and refresh
    S_OdrPrms.DurMap = S_OdrPrms.DurMap+0.5;
    if S_OdrPrms.DurMap>30
        S_OdrPrms.DurMap=30;
    end
    strTmp = num2str(S_OdrPrms.DurMap);
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.0');
    end
    set (S_PnlCtrls.hTxtDurMap,'String',strTmp)
end
%==================================================================
function fcnBtnDurClnDec(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % decrement duration of tubing clean period and refresh
    S_OdrPrms.DurCln = S_OdrPrms.DurCln-5;
    if S_OdrPrms.DurCln<5
        S_OdrPrms.DurCln=5;
    end
    strTmp = num2str(S_OdrPrms.DurCln);
    if numel(strTmp)==1
        strTmp=strcat('0',strTmp);
    end
    set (S_PnlCtrls.hTxtDurCln,'String',strTmp)
end
%==================================================================
function fcnBtnDurClnInc(~,~)
    global S_OdrPrms
    global S_PnlCtrls
    % increment duration of tubing clean period and refresh
    S_OdrPrms.DurCln = S_OdrPrms.DurCln+5;
    if S_OdrPrms.DurCln>60
        S_OdrPrms.DurCln=60;
    end
    strTmp = num2str(S_OdrPrms.DurCln);
    if numel(strTmp)==1
        strTmp=strcat('0',strTmp);
    end
    set (S_PnlCtrls.hTxtDurCln,'String',strTmp)
end
%==================================================================
function fcnBtnDspLimLoDec(~,~)
    global S_DspPrms
    global S_PnlCtrls
    % decrement limits on display low limit and refresh
    S_DspPrms.arrLims(1) = S_DspPrms.arrLims(1)-0.002;
    if S_DspPrms.arrLims(1)<0.90
        S_DspPrms.arrLims(1)=0.90;
    end
    strTmp = num2str(S_DspPrms.arrLims(1));
    if numel(strTmp)==4
        strTmp=strcat(strTmp,'0');
    end
    set (S_PnlCtrls.hTxtDspLimLo,'String',strTmp)
    set(S_PnlCtrls.hAxesMap,'CLim', S_DspPrms.arrLims);
    set(S_PnlCtrls.hAxesSeqFrm,'CLim', S_DspPrms.arrLims);
end
%==================================================================
function fcnBtnDspLimLoInc(~,~)
    global S_DspPrms
    global S_PnlCtrls
    % increment limits on display low limit and refresh
    S_DspPrms.arrLims(1) = S_DspPrms.arrLims(1)+0.002;
    if S_DspPrms.arrLims(1)>0.998
        S_DspPrms.arrLims(1)=0.998;
    end
    strTmp = num2str(S_DspPrms.arrLims(1));
    if numel(strTmp)==4
        strTmp=strcat(strTmp,'0');
    end
    set (S_PnlCtrls.hTxtDspLimLo,'String',strTmp)
    set(S_PnlCtrls.hAxesMap,'CLim', S_DspPrms.arrLims);
    set(S_PnlCtrls.hAxesSeqFrm,'CLim', S_DspPrms.arrLims);
end
%==================================================================
function fcnBtnDspLimHiDec(~,~)
    global S_DspPrms
    global S_PnlCtrls
    % decrement limits on display hi limit and refresh
    S_DspPrms.arrLims(2) = S_DspPrms.arrLims(2)-0.002;
    if S_DspPrms.arrLims(2)<1.00
        S_DspPrms.arrLims(2)=1.00;
    end
    strTmp = num2str(S_DspPrms.arrLims(2));
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.000');
    elseif numel(strTmp)==4
        strTmp=strcat(strTmp,'0');
    end
    set (S_PnlCtrls.hTxtDspLimHi,'String',strTmp)
    set(S_PnlCtrls.hAxesMap,'CLim', S_DspPrms.arrLims);
    set(S_PnlCtrls.hAxesSeqFrm,'CLim', S_DspPrms.arrLims);
end
%==================================================================
function fcnBtnDspLimHiInc(~,~)
    global S_DspPrms
    global S_PnlCtrls
    % increment limits on display hi limit and refresh
    S_DspPrms.arrLims(2) = S_DspPrms.arrLims(2)+0.002;
    if S_DspPrms.arrLims(2)>1.20
        S_DspPrms.arrLims(2)=1.20;
    end
    strTmp = num2str(S_DspPrms.arrLims(2));
    if numel(strTmp)==1
        strTmp=strcat(strTmp,'.000');
    elseif numel(strTmp)==4
        strTmp=strcat(strTmp,'0');
    end
    set (S_PnlCtrls.hTxtDspLimHi,'String',strTmp)
    set(S_PnlCtrls.hAxesMap,'CLim', S_DspPrms.arrLims);
    set(S_PnlCtrls.hAxesSeqFrm,'CLim', S_DspPrms.arrLims);
end


