function fcnIntrinsicNIsetup_30

    global sessNI
 
    % create DIO objects for control of valves and stimulus ID stamp
    sessNI = daq.createSession('ni');
    warning('off','daq:Session:onDemandOnlyChannelsAdded');
    sessNI.addDigitalChannel('Dev1','Port0/Line0:1', 'OutputOnly');
    sessNI.addDigitalChannel('Dev1','Port0/Line22:27', 'OutputOnly');
    sessNI.outputSingleScan([0 0 0 0 0 0 0 0]);
    warning('on','daq:Session:onDemandOnlyChannelsAdded');
    
end

    
