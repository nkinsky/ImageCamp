function [Y,b] = pastalkova(X)
[~,b]=max(X,[],2);
[~,b]=sort(b);
Y=X(b,:);




end