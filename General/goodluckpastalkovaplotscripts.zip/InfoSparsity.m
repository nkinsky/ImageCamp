function [info,sparsity,mehtasparsity] = InfoSparsity(counts, time, minoccupancy, dt)

%This function calculates the Skaggs(1993) information density (bits per 
%spike) and sparsity score

%Length of input arguments must agree
if numel(counts)~=numel(time)
    error('Length of counts must equal length of time');
end

if ~exist('minoccupancy','var')
    minoccupancy=0;
end

%Linearize vectors (if not already)
counts=counts(:);
time=time(:);

%Remove any entries that do not have sufficient temporal occupancy
notime = (time <= minoccupancy);
counts(notime)=[];
time(notime)=[];

if exist('dt','var')
    time=time*dt; %Convert time bins to seconds
end

rates = counts./time; %firing rate by position
meanrate = sum(counts)/sum(time); %mean firing rate for session
pbins = time/sum(time); %probability of occupancy for each bin



if(meanrate==0); info = 0; sparsity = 0; mehtasparsity=0;
else
    %Calculate information score
    log_rates = log2(rates/meanrate);
    log_rates(isinf(log_rates)) = 0;
    info = sum(pbins.*(rates/meanrate).*log_rates);
        
    %Calculate sparsity score
    sparsity=(sum(pbins.*rates)^2)./sum(pbins.*rates.^2);
    
    %Mehta sparsity score
    x=1/length(rates);
    mehtasparsity=(x*sum(rates).^2)/(x*sum(rates.^2));
end