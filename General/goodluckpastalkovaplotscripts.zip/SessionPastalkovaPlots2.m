% This script will plot rasters for each cell in a session and pastalkvova plots  
% 
fileList = getAllNEXFiles(uigetdir);
nexFile = readNexFileM(fileList{4});
load('jennajameson.mat')

% filename = 'C:\Users\Nick\Documents\MATLAB\nrobinson\Neural files and workspaces\Prospero\Prospero_20_12_13L_1_4-RC_MRG-EVE.nex'; 
% [nexFile] = readNexFileOriginal(filename);
SessionNumber = 26; % Change this for the session you want to analyse
NoTrials = length(history.sessions(1,SessionNumber).objects); %Change second number for session

%Get laser data
evTS = nexFile.events{cellfun(@(a)  strcmp(a.name,'Keyboard7'),nexFile.events)}.timestamps;
laserTS = history.sessions(1,SessionNumber).laser; % or use other line for timestamps
%laserTS = ismember(evTS, nexFile.events{8}.timestamps); %creates logical array classifying treadmill runs
firstlaser=find(laserTS,1,'first');
prelaserind=1:firstlaser-1;
prelaserfirsthalfind=1:(firstlaser)/2; % add minus one after first laser if odd.  
prelasersecondind=(((firstlaser)/2):firstlaser-1);
laseronind=logical(laserTS);
laseroffind=~laserTS;
laseroffind(prelaserind)=false;

%Split by objects
ObjAPrelaserind = (history.sessions(1,SessionNumber).objects(prelaserind)==0);
ObjBPrelaserind = (history.sessions(1,SessionNumber).objects(prelaserind)==1);
ObjALaserONind = (history.sessions(1,SessionNumber).objects(laseronind)==0);
ObjBLaserONind = (history.sessions(1,SessionNumber).objects(laseronind)==1);
ObjALaserOFFind = (history.sessions(1,SessionNumber).objects(laseroffind)==0);
ObjBLaserOFFind = (history.sessions(1,SessionNumber).objects(laseroffind)==1);

% SecondThirdind = zeros(1,NoTrials)';
% SecondThirdind(21:45) = ones(1,25)';
% SecondThirdind = logical(SecondThirdind); % change these to be flexible across sessions
% lastThirdind = zeros(1,NoTrials)';
% lastThirdind(46:70) = ones(1,25)'; % change all this to be flexible!
% lastThirdind = logical(lastThirdind);
% TwentytoThrity = zeros(1,70)';
% TwentytoThrity(21:30) = ones(1,10)';
% TwentytoThrity = logical(TwentytoThrity);
% ThirtytoForty = zeros(1,70)';
% ThirtytoForty(31:40) = ones(1,10)';
% ThirtytoForty = logical(ThirtytoForty);
% FortytoFifty = zeros(1,70)';
% FortytoFifty(41:50) = ones(1,10)';
% FortytoFifty = logical(FortytoFifty);
% FiftytoSixty = zeros(1,70)';
% FiftytoSixty(51:60) = ones(1,10)';
% FiftytoSixty = logical(FiftytoSixty);
% SixtytoSeventy = zeros(1,70)';
% SixtytoSeventy(61:70) = ones(1,10)';
% SixtytoSeventy = logical(SixtytoSeventy);

% creating indexs for the first and last blocks of laser or non laser
% trials

% Cheese = find(laserTS(firstlaser:length(evTS))==0,12); % change last number for block size
% firstNNOlaserin = Cheese+(firstlaser-1);              % keep consistent for laser and non laser
% Cheese = find(laserTS(firstlaser:length(evTS))==0,12, 'last');
% lastNNOlaserin = Cheese+(firstlaser-1);
% firstNLaserin = find(laserTS==1,12);
% lastNLaserin = find(laserTS==1,12, 'last');
% Cheese = zeros(1,70)';
% Cheese(firstNNOlaserin) = ones(1,length(firstNNOlaserin))';
% firstNNOlaserind = logical(Cheese);
% Cheese = zeros(1,70)';
% Cheese(lastNNOlaserin) = ones(1,length(lastNNOlaserin))';
% lastNNOlaserind = logical(Cheese);
% Cheese = zeros(1,70)';
% Cheese(firstNLaserin) = ones(1,length(firstNLaserin))';
% firstNLaserind = logical(Cheese);
% Cheese = zeros(1,70)';
% Cheese(lastNLaserin) = ones(1,length(lastNLaserin))';
% lastNLaserind = logical(Cheese);



%Get neural data
for i = 1:length(nexFile.neurons)
    neuron(i).ts = nexFile.neurons{i}.timestamps;
    neuron(i).name = nexFile.neurons{i}.name;
end


%%
% Raster program (from Ben)

% Set raster plot save directory
savepath='C:\Users\Nick\Desktop\Projects\MECINAC\Figures\Rastas\Prospero20_12_134sL'; %[]
if isempty(savepath)
    savepath=uigetdir('C:\');
end

timerange=8; %range of time from treadmill onset to display
treadmillduration=8; %8 seconds treadmill duration.
treadmillcolor=[.9 .9 .9]; %light gray

spike={neuron(:).ts}'; %Convert timestamp struct to cell
[~,spiketrial]=cellfun(@(x) histc(x,[-inf; evTS; inf]),spike,'uni',false); %Categorize spiketimestamps by trial
trialstarts=[0;evTS];
modspike=cellfun(@(x,y) x-trialstarts(y),spike,spiketrial,'uni',false); %substracts the timestamp of treadmill of each lap from ts, so each raster starts at zero

%Remove first trial (before first treadmill run) by negating in "order"
for m=1:numel(spiketrial)
    modspike{m}(spiketrial{m}==1)=[];
    spiketrial{m}(spiketrial{m}==1)=[];
end
spiketrial=cellfun(@(x) x-1, spiketrial,'uni',false);

for m=1:numel(neuron)
    raster([modspike{m} spiketrial{m}],'epochs',[0 treadmillduration],'groups',laserTS(1:end)+1,'xlim',[0 timerange],'patchcolor',treadmillcolor,'epochedgecolor',[0 0 0]);
    line([0 timerange], 1-(firstlaser-0.55)/numel(trialstarts)*[1 1],'color','b','linewidth',1); %delineates baseline from rest (only works if ylim =[0 1])
    line([2 2], [0 1000],'color','r','linewidth',2);
    line([4 4], [0 1000],'color','r','linewidth',2);
    title(neuron(m).name,'Interpreter', 'none');
    %saveas(gcf,[savepath '\' neuron(m).name, '.jpg']);
end

%%

Tbin = 120; % change the number of time bins

%Calculate information scores
%pre
%binnedPop = trial x neuron x time
binnedPop=spkmatTime(neuron,0,8,Tbin,evTS,0); % from (x, to y, seconds with # time bins)

timeBin = repmat(1:size(binnedPop,3),size(binnedPop,1),1);
timeBin = timeBin(prelaserind,:);
timeBin = timeBin(:);

for i = 1:size(binnedPop,2)
   
    spks = squeeze(binnedPop(prelaserind,i,:));
    spks = spks(:);
[infoTemp(i,:,1)] = InfoSparsity(spks, timeBin);

end
%%
%laserOFF

timeBin = repmat(1:size(binnedPop,3),size(binnedPop,1),1);
timeBin = timeBin(laseroffind,:);
timeBin = timeBin(:);

for i = 1:size(binnedPop,2)
   
    spks = squeeze(binnedPop(laseroffind,i,:));
    spks = spks(:);
[infoTemp(i,:,2)] = InfoSparsity(spks, timeBin);

end
%%
%%laserON
timeBin = repmat(1:size(binnedPop,3),size(binnedPop,1),1);
timeBin = timeBin(laseronind,:);
timeBin = timeBin(:);

for i = 1:size(binnedPop,2)
   
    spks = squeeze(binnedPop(laseronind,i,:));
    spks = spks(:);
[infoTemp(i,:,3)] = InfoSparsity(spks, timeBin);

end
%%
[preInfo,idx] = max(infoTemp(:,:,1),[],2);
laserOFFinfo = max(infoTemp(:,:,2),[],2);
laserONinfo = max(infoTemp(:,:,3),[],2);
bar(nanmean([preInfo laserONinfo laserOFFinfo]))

%%
%how did the laser affect firing at the pre-stim maximal info bin
goodIDXOFF = sub2ind(size(infoTemp),[1:length(idx)]',idx,2*ones(length(idx),1));
goodIDXON = sub2ind(size(infoTemp),[1:length(idx)]',idx,3*ones(length(idx),1));

laserOFFinfo_max = infoTemp(goodIDXOFF);
laserONinfo_max = infoTemp(goodIDXON);
deltaMaxBin = preInfo - laserONinfo_max;
plot(idx,deltaMaxBin,'x')

%%
deltaMean = infoTemp(:,:,1) - infoTemp(:,:,3);
plot(nanmean(deltaMean))

plot(nanmean(infoTemp(:,:,1)))
%%
% Extract data for pastalkova plots

     trialaverage  = squeeze(nanmean(binnedPop,1));
     meanrate=nanmean(trialaverage,2);
     stdrate=nanstd(trialaverage,[],2);
     maxrate=nanmax(trialaverage,[],2);
     binnedPopu = squeeze(nanmean(binnedPop,1));
     keepCell = (maxrate > 2*stdrate+meanrate) & meanrate<10 & maxrate>0.5 & preInfo>5; % change this to alter cell selection
     binnedPop = binnedPop(:,keepCell,:);
       % should I filter by specifically prelaser?
Prelaser = squeeze(mean(binnedPop(prelaserind,:,:),1));
laserOFF = squeeze(mean(binnedPop(laseroffind,:,:),1));
laserON = squeeze(mean(binnedPop(laseronind,:,:),1));

%Split by objects
ObjAPrelaser = squeeze(mean(binnedPop(ObjAPrelaserind,:,:),1));
ObjBPrelaser = squeeze(mean(binnedPop(ObjBPrelaserind,:,:),1));
ObjALaserON = squeeze(mean(binnedPop(ObjALaserONind,:,:),1));
ObjBLaserON = squeeze(mean(binnedPop(ObjBLaserONind,:,:),1));
ObjALaserOFF = squeeze(mean(binnedPop(ObjALaserOFFind,:,:),1));
ObjBLaserOFF = squeeze(mean(binnedPop(ObjBLaserOFFind,:,:),1));

%Split by time in session
% SecondThirdind = squeeze(mean(binnedPop(SecondThirdind,:,:),1));
% lastThirdind = squeeze(mean(binnedPop(lastThirdind,:,:),1));
% TwentytoThrity = squeeze(mean(binnedPop(TwentytoThrity,:,:),1));
% ThirtytoForty = squeeze(mean(binnedPop(ThirtytoForty,:,:),1));
% FortytoFifty = squeeze(mean(binnedPop(FortytoFifty,:,:),1));
% FiftytoSixty = squeeze(mean(binnedPop(FiftytoSixty,:,:),1));
% SixtytoSeventy = squeeze(mean(binnedPop(SixtytoSeventy,:,:),1));

% firstNNOLaser = squeeze(mean(binnedPop(firstNNOlaserind,:,:),1));
% lastNNOLaser = squeeze(mean(binnedPop(lastNNOlaserind,:,:),1));
% firstNLaser = squeeze(mean(binnedPop(firstNLaserind,:,:),1));
% lastNLaser = squeeze(mean(binnedPop(lastNLaserind,:,:),1));

kernel = gausswin(13)./sum(gausswin(13));

SmoothedPreLaser = convn(Prelaser,kernel','same');
SmoothedlaserOFF = convn(laserOFF,kernel','same');
SmoothedlaserON = convn(laserON,kernel','same');

%Split by objects
SmObjAPrelaser = convn(ObjAPrelaser,kernel','same');
SmObjBPrelaser = convn(ObjBPrelaser,kernel','same');
SmObjALaserON = convn(ObjALaserON,kernel','same');
SmObjBLaserON = convn(ObjBLaserON,kernel','same');
SmObjALaserOFF = convn(ObjALaserOFF,kernel','same');
SmObjBLaserOFF = convn(ObjBLaserOFF,kernel','same');

% SmoothedSecondThirdind = convn(SecondThirdind,kernel','same');
% SmoothedlastThirdind = convn(lastThirdind,kernel','same');
% SmoothedTwentytoThrity = convn(TwentytoThrity,kernel','same');
% SmoothedThirtytoForty = convn(ThirtytoForty,kernel','same');
% SmoothedFortytoFifty = convn(FortytoFifty,kernel','same');
% SmoothedFiftytoSixty = convn(FiftytoSixty,kernel','same');
% SmoothedSixtytoSeventy = convn(SixtytoSeventy,kernel','same');

% SmoothedfirstNNOLaser = convn(firstNNOLaser,kernel','same');
% SmoothedlastNNOLaser = convn(lastNNOLaser,kernel','same');
% SmoothedfirstNLaser = convn(firstNLaser,kernel','same');
% SmoothedlastNLaser = convn(lastNLaser,kernel','same');

% SmoothedfirstHPreLaser = convn(firstHPreLaser,kernel','same');
% SmoothedlastHPreLaser = convn(lastHPreLaser,kernel','same');

%%
% Collate sessions by saving new variable then sticthing

Prelaser1 = Prelaser;
laserOFF1 = laserOFF;
laserON1 = laserON;

Prelaser2 = Prelaser;
laserOFF2 = laserOFF;
laserON2 = laserON;

Prelaser3 = Prelaser;
laserOFF3 = laserOFF;
laserON3 = laserON;


ObjAPrelaser1 = ObjAPrelaser;
ObjBPrelaser1 = ObjBPrelaser;
ObjALaserON1 = ObjALaserON;
ObjBLaserON1 = ObjBLaserON;
ObjALaserOFF1 = ObjALaserOFF;
ObjBLaserOFF1 = ObjBLaserOFF;

ObjAPrelaser2 = ObjAPrelaser;
ObjBPrelaser2 = ObjBPrelaser;
ObjALaserON2 = ObjALaserON;
ObjBLaserON2 = ObjBLaserON;
ObjALaserOFF2 = ObjALaserOFF;
ObjBLaserOFF2 = ObjBLaserOFF;

ObjAPrelaser3 = ObjAPrelaser;
ObjBPrelaser3 = ObjBPrelaser;
ObjALaserON3 = ObjALaserON;
ObjBLaserON3 = ObjBLaserON;
ObjALaserOFF3 = ObjALaserOFF;
ObjBLaserOFF3 = ObjBLaserOFF;

L22CollatedPreLaser = [Prelaser1; Prelaser2];
L22CollatedLaserOFF = [laserOFF1; laserOFF2];
L22CollatedLaserON = [laserON1; laserON2];

L22CollatedObjAPrelaser = [ObjAPrelaser1; ObjAPrelaser2];
L22CollatedObjBPrelaser = [ObjBPrelaser1; ObjBPrelaser2];
L22CollatedObjALaserON= [ObjALaserON1; ObjALaserON2];
L22CollatedObjBLaserON = [ObjBLaserON1; ObjBLaserON2];
L22CollatedObjALaserOFF = [ObjALaserOFF1; ObjALaserOFF2];
L22CollatedObjBLaserOFF = [ObjBLaserOFF1; ObjBLaserOFF2];

kernel = gausswin(13)./sum(gausswin(13));
L22CollatedSmoothedPreLaser = convn(L22CollatedPreLaser,kernel','same');
L22CollatedSmoothedLaserOFF = convn(L22CollatedLaserOFF,kernel','same');
L22CollatedSmoothedLaserON = convn(L22CollatedLaserON,kernel','same');

L22CollatedObjAPrelaser = convn(L22CollatedObjAPrelaser,kernel','same');
L22CollatedObjBPrelaser = convn(L22CollatedObjBPrelaser,kernel','same');
L22CollatedObjALaserON= convn(L22CollatedObjALaserON,kernel','same');
L22CollatedObjBLaserON = convn(L22CollatedObjBLaserON,kernel','same');
L22CollatedObjALaserOFF = convn(L22CollatedObjALaserOFF,kernel','same');
L22CollatedObjBLaserOFF = convn(L22CollatedObjBLaserOFF,kernel','same');

[L22CollatedSmoothedPreLaser,d] = pastalkova(L22CollatedSmoothedPreLaser); % orders the rows by their maximum rates
L22CollatedSmoothedLaserOFF = L22CollatedSmoothedLaserOFF(d,:);
L22CollatedSmoothedLaserON = L22CollatedSmoothedLaserON(d,:);

[L22CollatedObjAPrelaser, e] =  pastalkova(L22CollatedObjAPrelaser);
[L22CollatedObjBPrelaser, f] = pastalkova(L22CollatedObjBPrelaser);
L22CollatedObjALaserON= L22CollatedObjALaserON(e,:);
L22CollatedObjBLaserON = L22CollatedObjBLaserON(f,:);
L22CollatedObjALaserOFF = L22CollatedObjALaserOFF(e,:);
L22CollatedObjBLaserOFF = L22CollatedObjBLaserOFF(f,:);
L22CollObjAPrelaserOrderedB =  L22CollatedObjAPrelaser(f,:);
L22CollObjBPrelaserOrderedA = L22CollatedObjBPrelaser(e,:);

% Plot the above

savepath='C:\Users\Nick\Desktop\Projects\MECINAC\Figures\Pastalkova Plots\Prospero\Collated4sSessions\'; %[]
if isempty(savepath)
    savepath=uigetdir('C:\');
end


figure
imagesc(L22CollatedSmoothedPreLaser./repmat(max(L22CollatedSmoothedPreLaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Pre laser trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [length(L22CollatedSmoothedPreLaser(:,1)))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Pre laser trials', '.jpg']);

figure
imagesc(L22CollatedSmoothedLaserOFF./repmat(max(L22CollatedSmoothedPreLaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Laser OFF trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Laser OFF trials', '.jpg']);

figure
imagesc(L22CollatedSmoothedLaserON./repmat(max(L22CollatedSmoothedPreLaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Laser ON trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Laser ON trials', '.jpg']);

figure
imagesc(L22CollatedSmoothedLaserOFF./repmat(max(L22CollatedSmoothedLaserOFF,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Laser OFF trials self normalized')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Laser OFF trials self normalized', '.jpg']);


figure
imagesc(L22CollatedSmoothedLaserON./repmat(max(L22CollatedSmoothedLaserON,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Laser ON trials self normalized')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Laser ON trials self normalized', '.jpg']);

figure
imagesc(L22CollatedObjAPrelaser./repmat(max(L22CollatedObjAPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Collated Object A Pre laser trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object A Pre laser trials', '.jpg']);

figure
imagesc(L22CollatedObjALaserON./repmat(max(L22CollatedObjAPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Collated Object A Laser ON trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object A Laser ON trials', '.jpg']);

figure
imagesc(L22CollatedObjALaserOFF./repmat(max(L22CollatedObjAPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Collated Object A Laser OFF')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object A Laser OFF', '.jpg']);

figure
imagesc(L22CollatedObjBPrelaser./repmat(max(L22CollatedObjBPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Collated Object B Pre Laser trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object B Pre Laser trials', '.jpg']);

figure
imagesc(L22CollatedObjBLaserON./repmat(max(L22CollatedObjBPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Collated Object B Laser ON trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object B Laser ON trials', '.jpg']);

figure
imagesc(L22CollatedObjBLaserOFF./repmat(max(L22CollatedObjBPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Collated Object B Laser OFF trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object B Laser OFF trials', '.jpg']);

figure
imagesc(L22CollObjAPrelaserOrderedB./repmat(max(L22CollatedObjBPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Collated Object A Pre laser trials Ordered and Nomralized by B')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object A Pre laser trials Ordered and Nomralized by B', '.jpg']);

figure
imagesc(L22CollObjBPrelaserOrderedA./repmat(max(L22CollatedObjAPrelaser,[],2),1,size(L22CollatedSmoothedPreLaser,2)), [ 0 1])
title('Collated Object B Pre laser trials Ordered and Nomralized by A')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%for 2s
% line([Tbin/2 Tbin/2], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)%4s
line([(Tbin/8)*5 (Tbin/8)*5], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 length(L22CollatedSmoothedPreLaser(:,1))], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Collated Object B Pre laser trials Ordered and Nomralized by A', '.jpg']);

%%

%Order cells by max
[SmoothedPreLaser,b] = pastalkova(SmoothedPreLaser); % orders the rows by their maximum rates
SmoothedlaserOFF = SmoothedlaserOFF(b,:);
SmoothedlaserON = SmoothedlaserON(b,:);

[SmObjAPrelaserSO,c] = pastalkova(SmObjAPrelaser); %self ordered
SmObjBPrelaserOrdA = SmObjBPrelaser(c,:); % B ordered by A
[SmObjBPrelaserSO,d] = pastalkova(SmObjBPrelaser); %B self ordered
SmObjAPrelaserOrdB = SmObjAPrelaser(d,:); %A ordered by B
SmObjAPrelaser = SmObjAPrelaser(b,:);
SmObjBPrelaser = SmObjBPrelaser(b,:);
SmObjALaserON = SmObjALaserON(b,:);
SmObjBLaserON = SmObjBLaserON(b,:);
SmObjALaserOFF = SmObjALaserOFF(b,:);
SmObjBLaserOFF = SmObjBLaserOFF(b,:);

% SmoothedSecondThirdind = SmoothedSecondThirdind(b,:);
% SmoothedlastThirdind = SmoothedlastThirdind(b,:);
% SmoothedTwentytoThrity = SmoothedTwentytoThrity(b,:);
% SmoothedThirtytoForty = SmoothedThirtytoForty(b,:);
% SmoothedFortytoFifty = SmoothedFortytoFifty(b,:);
% SmoothedFiftytoSixty = SmoothedFiftytoSixty(b,:);
% SmoothedSixtytoSeventy = SmoothedSixtytoSeventy(b,:);
% SmoothedfirstNNOLaser = SmoothedfirstNNOLaser(b,:);
% SmoothedlastNNOLaser = SmoothedlastNNOLaser(b,:);
% SmoothedfirstNLaser = SmoothedfirstNLaser(b,:);
% SmoothedlastNLaser = SmoothedlastNLaser(b,:);
% SmoothedfirstHPreLaser = SmoothedfirstHPreLaser(b,:);
% SmoothedlastHPreLaser = SmoothedlastHPreLaser(b,:);



%% filter

% ben's
% gfilter = fspecial('gaussian',12,4);
%     
%     for i = 1:size(rates,1);
%         tosmooth = squeeze(rates(i,:,:));
%         rates(i,:,:) = shiftdim(imfilter(tosmooth,gfilter),-1);
%     end


%% Use this to normalize by max at any point
maxPerTypeMat = ([max(SmoothedPreLaser,[],2) max(SmoothedlaserOFF,[],2) max(SmoothedlaserON,[],2)]);
neuronmax=max(maxPerTypeMat(1));

savepath='C:\Users\Nick\Desktop\Projects\MECINAC\Figures\Pastalkova Plots\MexicanBlend\13th Feb L2_2'; %[]
if isempty(savepath)
    savepath=uigetdir('C:\');
end

figure
imagesc(SmoothedPreLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Pre laser trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
hold on
line([Tbin/4 Tbin/4], [0 sum(keepCell)+0.5], 'color', 'black', 'linewidth', 2)%for 2s
line([Tbin/2 Tbin/2], [0 sum(keepCell)+0.5], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)%4s
% line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
%saveas(gcf,[savepath '\' 'Pre laser trials', '.jpg']);

figure
imagesc(SmoothedlaserOFF./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
title('Laser OFF trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
line([Tbin/4 Tbin/4], [0 sum(keepCell)+0.5], 'color', 'black', 'linewidth', 2)%for 2s
line([Tbin/2 Tbin/2], [0 sum(keepCell)+0.5], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
%saveas(gcf,[savepath '\' 'Laser OFF trials', '.jpg']);

figure
imagesc(SmoothedlaserON./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
title('Laser ON trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
line([Tbin/4 Tbin/4], [0 sum(keepCell)+0.5], 'color', 'black', 'linewidth', 2)
line([Tbin/2 Tbin/2], [0 sum(keepCell)+0.5], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
%saveas(gcf,[savepath '\' 'Laser ON trials', '.jpg']);

figure
imagesc(SmObjAPrelaserSO./repmat(max(SmObjAPrelaserSO,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object A Pre laser trials Self Ordered')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object A Pre laser trials Self Ordered', '.jpg']);

figure
imagesc(SmObjBPrelaserOrdA./repmat(max(SmObjAPrelaserSO,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object B Pre laser trials ordered by Object A trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object B Pre laser trials ordered by Object A trials', '.jpg']);

figure
imagesc(SmObjBPrelaserSO./repmat(max(SmObjBPrelaserSO,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object B Pre laser trials Self Ordered')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object B Pre laser trials Self Ordered', '.jpg']);

figure
imagesc(SmObjAPrelaserOrdB./repmat(max(SmObjBPrelaserSO,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object A Pre laser trials ordered by Object B trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object A Pre laser trials ordered by Object B trials', '.jpg']);

figure
imagesc(SmObjAPrelaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object A Pre laser trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object A Pre laser trials', '.jpg']);

figure
imagesc(SmObjBPrelaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object B Pre laser trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object B Pre laser trials', '.jpg']);

figure
imagesc(SmObjALaserON./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object A laser ON trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object A laser ON trials', '.jpg']);

figure
imagesc(SmObjBLaserON./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object B laser ON trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object B laser ON trials', '.jpg']);

figure
imagesc(SmObjALaserOFF./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object A laser OFF trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object A laser OFF trials', '.jpg']);

figure
imagesc(SmObjBLaserOFF./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1]) % change how nomralized
title('Object B laser OFF trials')
set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
% line([Tbin/2 Tbin/2], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([Tbin/8 Tbin/8], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
line([(Tbin/8)*5 (Tbin/8)*5], [0 sum(keepCell)], 'color', 'black', 'linewidth', 2)
xlabel('Time')
ylabel('Cell Number')
saveas(gcf,[savepath '\' 'Object B laser OFF trials', '.jpg']);

% figure
% imagesc(SmoothedSecondThirdind./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Second third of trials - Mixed Laser and No Laser')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedlastThirdind./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Last third of trials - Mixed Laser and No Laser')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')

% figure
% imagesc(SmoothedTwentytoThrity./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Trials 20 to 30 - Mixed Laser and No Laser')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedThirtytoForty./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Trials 30 to 40 - Mixed Laser and No Laser')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedFortytoFifty./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Trials 40 to 50 - Mixed Laser and No Laser')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedFiftytoSixty./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Trials 50 to 60 - Mixed Laser and No Laser')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedSixtytoSeventy./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Trials 60 to 70 - Mixed Laser and No Laser')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')

%plots for first and last laser and non-laser blocks



%%

% figure
% imagesc(SmoothedfirstNNOLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('First 12 No laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% line([Tbin/4 Tbin/4], [0 sum(keepCell)],'color','r','linewidth',2);
% line([Tbin/2 Tbin/2], [0 sum(keepCell)],'color','r','linewidth',2);
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedlastNNOLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Last 12 No laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedfirstNLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('First 12 laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedlastNLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Last 12 laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% % plots which calculate the difference between normalized matrices
% 
% figure
% imagesc((SmoothedfirstNNOLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))) ...
%     -(SmoothedPreLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))), [ 0 1]);
% title('Difference between prelaser and first 12 No laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc((SmoothedlastNNOLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))) ...
%     -(SmoothedPreLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))), [ 0 1]);
% title('Difference between prelaser and last 12 No laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc((SmoothedfirstNLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))) ...
%     -(SmoothedPreLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))), [ 0 1]);
% title('Difference between prelaser and first 12 laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc((SmoothedlastNLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))) ...
%     -(SmoothedPreLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2))), [ 0 1]);
% title('Difference between prelaser and last 12 laser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')

% figure
% imagesc(SmoothedfirstHPreLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('First half of Prelaser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')
% 
% figure
% imagesc(SmoothedlastHPreLaser./repmat(max(SmoothedPreLaser,[],2),1,size(SmoothedPreLaser,2)), [ 0 1])
% title('Second half of Prelaser trials')
% set(gca,'XTick',0:120/8:120,'XTickLabel',0:8)
% % line((Tbin/4),0:sum(keepCell),'LineWidth',3)
% % line((Tbin/2),0:sum(keepCell),'LineWidth',3)
% xlabel('Time')
% ylabel('Cell Number')

% Make raster centered on object sample time and split by object type...

timerange=4; %range of time from treadmill onset to display
Samplewindow = 4; %8 seconds treadmill duration.
treadmillcolor=[.9 .9 .9]; %light gray
ObjTS = nexFile.events{cellfun(@(a)  strcmp(a.name,'Keyboard8'),nexFile.events)}.timestamps;

spike={neuron(:).ts}'; %Convert timestamp struct to cell
[~,spiketrial]=cellfun(@(x) histc(x,[-inf; evTS; inf]),spike,'uni',false); %Categorize spiketimestamps by trial
trialstarts=[0;evTS];
modspike=cellfun(@(x,y) x-trialstarts(y),spike,spiketrial,'uni',false); %substracts the timestamp of treadmill of each lap from ts, so each raster starts at zero

%Remove first trial (before first treadmill run) by negating in "order"
for m=1:numel(spiketrial)
    modspike{m}(spiketrial{m}==1)=[];
    spiketrial{m}(spiketrial{m}==1)=[];
end
spiketrial=cellfun(@(x) x-1, spiketrial,'uni',false);

for m=1:numel(neuron)
    raster([modspike{m} spiketrial{m}],'epochs',[0 Samplewindow],'groups',[1; (history.sessions(1,SessionNumber).objects)+1],'xlim',[0 timerange],'patchcolor',treadmillcolor,'epochedgecolor',[0 0 0]);
%     line([0 timerange], 1-(firstlaser+0.5)/numel(trialstarts)*[1 1],'color','b','linewidth',1); %delineates baseline from rest (only works if ylim =[0 1])
%     line(1, [0:1000],'color','r','linewidth',10);
%     line(5, [0:1000],'color','r','linewidth',10);
    title(neuron(m).name,'Interpreter', 'none');
%     saveas(gcf,[savepath '\' neuron(m).name, '.jpg']);
end


%%
% Run data into Jason Cs phase precession script
fileList = getAllNEXFiles(uigetdir);
nexFile = readNexFileOriginal(fileList{6});
load('Prospero_History_15th_16th_17th_20thCorrect.mat')
SessionNumber = 22; %16th
NoTrials = length(history.sessions(1,SessionNumber).objects); 

for i = 1:length(nexFile.neurons)
    neuron(i).ts = nexFile.neurons{i}.timestamps;
    neuron(i).name = nexFile.neurons{i}.name;
end

Tbin = 120; % change the number of time bins
evTS = nexFile.events{cellfun(@(a)  strcmp(a.name,'Keyboard7'),nexFile.events)}.timestamps;
binnedPop=spkmatTime(neuron,0,8,Tbin,evTS,0); % from (x, to y, seconds with # time bins)
trialaverage  = squeeze(nanmean(binnedPop,1));
     meanrate=nanmean(trialaverage,2);
     stdrate=nanstd(trialaverage,[],2);
     maxrate=nanmax(trialaverage,[],2);
binnedPop=spkmatTime(neuron,0,8,Tbin,evTS,0); % from (x, to y, seconds with # time bins)
binnedPopu = squeeze(nanmean(binnedPop,1));
keepCell = (maxrate > 2*stdrate+meanrate) & meanrate<10 & maxrate>1; % change this to alter cell selection
binnedPopu = binnedPopu(:,keepCell,:);

close all
for j = 1:length(neuron);
    figure
    spk_ts = neuron(1,j).ts;
    lfp_sig = nexFile.contvars{17,1}.data; %change to the terode you want for LFP source
    spk_state = cell2mat([arrayfun(@(i)spk_ts(spk_ts>evTS(i)&spk_ts<evTS(i+1))-evTS(i),1:numel(evTS)-1,'UniformOutput',false)';{spk_ts(spk_ts>evTS(end))-evTS(end)}]);
    
%    [~,spk_flds_pos]=find_fields('rm',binnedPopu(j,:)','occupancy',ones(numel(binnedPopu(1,:)),1)*NoTrials*(8/120),'binside',(8/120),'rng',[0 8],'i_cutoff',1,' 
   
analyze_precession(spk_ts,lfp_sig,'i_cutoff',0,'rm',binnedPopu(j,:)','occupancy',ones(numel(binnedPopu(1,:)),1)*NoTrials*(8/120),'binside',(8/120),'rng',[0 8],'i_cutoff',1,'spk_ts',spk_ts,'spk_state',spk_state,'vid_ts',nexFile.events{1}.timestamps);
   
    drawnow
end



% 
% timeBin = repmat(1:size(binnedPop,3),size(binnedPop,1),1); may be useful
% for splitting up later. 
% timeBin = timeBin(prelaserind,:);
% timeBin = timeBin(:);

